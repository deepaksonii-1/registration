<?php

  $DBhost = "http://sql202.ultimatefreehost.in/";
  $DBuser = "ltm_19659815";
  $DBpass = "D33p@ksoni";
  $DBname = "ltm_19659815_mydb";

  $DBcon = new MySQLi($DBhost,$DBuser,$DBpass,$DBname);

     if ($DBcon->connect_errno) {
         die("ERROR : -> ".$DBcon->connect_error);
     }
